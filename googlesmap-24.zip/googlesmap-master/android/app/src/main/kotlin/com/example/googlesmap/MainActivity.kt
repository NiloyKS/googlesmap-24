package com.example.googlesmap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
